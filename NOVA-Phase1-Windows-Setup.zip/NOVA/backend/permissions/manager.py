from __future__ import annotations

from dataclasses import dataclass

from backend.core import PermissionLevel, RiskLevel, settings


@dataclass(frozen=True)
class PermissionDecision:
    allowed: bool
    requires_confirmation: bool
    reason: str


class PermissionManager:
    def decide(self, *, permission: PermissionLevel, risk: RiskLevel, confirmed: bool = False) -> PermissionDecision:
        if settings.nova_safe_mode and permission > PermissionLevel.READ_ONLY:
            return PermissionDecision(False, False, "Safe Mode blocks executable or mutating actions.")

        if risk in {RiskLevel.HIGH, RiskLevel.CRITICAL} or permission >= PermissionLevel.EXTERNAL_COMMUNICATION:
            if not confirmed:
                return PermissionDecision(False, True, "Explicit user confirmation is required for this action.")

        return PermissionDecision(True, False, "Permission granted by current policy.")
