# NOVA Implementation Roadmap

## Phase 1 — Core UI + command system
Status: **implemented**

## Phase 2 — Task orchestration
Persist task/step state, asynchronous execution, cancellation tokens, retries and verification hooks.

## Phase 3 — Tool framework
Add strongly typed tool schemas, manifests, per-tool policy configuration and plugin loading.

## Phase 4 — Filesystem + shell
Add OS adapters, safer command allowlists, sandboxing, process isolation and resource limits.

## Phase 5 — Coding agent
Add repository inspection, code-edit transactions, test execution, lint/build verification and rollback support.

## Phase 6 — Browser automation
Use a browser automation adapter with approval checkpoints, session isolation and no access-control bypass.

## Phase 7 — Memory
Add scoped conversation/task memory, user-managed long-term memory, retention policies and export/delete controls.

## Phase 8 — Security
Add real authentication, session controls, CSRF/origin protection as applicable, rate limiting, secret store integration, structured security events and policy administration.

## Phase 9 — GitHub + email
Implement provider adapters and explicit approval workflows for publish/send actions.

## Phase 10 — Scheduler + recipes
Add durable scheduled jobs, idempotency and reusable automation definitions.

## Phase 11 — Voice
Add speech recognition, TTS and wake-word integration with an explicit microphone state indicator.

## Phase 12 — Screen understanding
Add opt-in screen capture with local processing options, retention controls and sensitive-content safeguards.

## Phase 13 — Testing
Add full unit/integration/security/e2e coverage and fault-injection tests.

## Phase 14 — Deployment
Add Docker, PostgreSQL migrations, reverse proxy, HTTPS, secret management, backups, observability and production hardening.
