from __future__ import annotations

from sqlalchemy.orm import Session

from backend.core import TaskPlan
from backend.permissions.manager import PermissionManager
from backend.services.audit import log_event
from backend.tools.builtin import build_registry


class Orchestrator:
    def __init__(self) -> None:
        self.permissions = PermissionManager()
        self.registry = build_registry()
        self._stopped = False

    def stop_all(self) -> None:
        self._stopped = True

    def reset_stop(self) -> None:
        self._stopped = False

    def execute(self, plan: TaskPlan, db: Session, *, preview_only: bool = False) -> dict:
        if self._stopped:
            return {"task_id": plan.task_id, "goal": plan.goal, "steps": [step.model_dump() | {"status": "interrupted", "result": {"message": "Emergency stop is active."}} for step in plan.steps]}
        log_event(db, event_type="task.created", status="ok", message=plan.goal, task_id=plan.task_id)
        output = []
        for step in plan.steps:
            if self._stopped:
                step.status = "interrupted"
                output.append(step.model_dump())
                break
            decision = self.permissions.decide(permission=step.permission, risk=step.risk, confirmed=False)
            if not decision.allowed:
                step.status = "preview" if decision.requires_confirmation else "blocked"
                step.result = {"message": decision.reason}
                log_event(db, event_type="permission", status=step.status, message=decision.reason, task_id=plan.task_id, tool=step.tool, risk=step.risk.value)
                output.append(step.model_dump())
                if not preview_only and decision.requires_confirmation:
                    # The API will expose the plan for user approval; execution stops here.
                    break
                continue

            if preview_only:
                step.status = "preview"
                step.result = {"message": "No changes made in preview mode."}
                output.append(step.model_dump())
                continue

            if step.tool:
                tool = self.registry.get(step.tool)
                result = tool.handler(".") if step.tool == "filesystem.inspect" else tool.handler("nova_preview.txt", "NOVA preview")
                step.status = "completed" if result.success else "failed"
                step.result = result.model_dump()
            else:
                step.status = "planned"
                step.result = {"message": "Agent-backed step is scaffolded; provider-specific execution is not enabled yet."}
            log_event(db, event_type="step", status=step.status, message=step.title, task_id=plan.task_id, tool=step.tool, risk=step.risk.value)
            output.append(step.model_dump())
        return {"task_id": plan.task_id, "goal": plan.goal, "steps": output}
