# NOVA Feature Status

| Area | Status | Notes |
|---|---|---|
| Command center | ✅ | Functional React UI |
| Command planner | ✅ | Rule-based Phase 1 intents |
| Permission manager | ✅ | Safe Mode + risk gates |
| Tool registry | ✅ | Structured tool metadata |
| Filesystem inspection | ✅ | Allowed-root constrained |
| Shell safety | ✅ | Safe-command set + confirmation gate |
| Audit log | ✅ | SQLite-backed |
| Memory CRUD | ✅ | SQLite-backed |
| AI provider abstraction | 🟡 | Interface exists; live provider wiring is next phase |
| Persistent task execution | 🟡 | Plan/result flow exists; durable async runner is next phase |
| Browser | ⏳ | Not implemented |
| GitHub | ⏳ | Not implemented |
| Email | ⏳ | Not implemented |
| Voice | ⏳ | Not implemented |
| Screen understanding | ⏳ | Not implemented |
| Scheduler | ⏳ | Not implemented |
| PostgreSQL | ⏳ | Target for production |
| Production auth | ⏳ | Required before exposing externally |
