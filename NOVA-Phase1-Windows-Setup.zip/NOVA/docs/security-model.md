# NOVA Security Model

## Security objectives

NOVA is an automation system with the ability to create side effects. Security is therefore a control plane, not a feature added after execution logic.

## Controls

1. **Least privilege** — each tool declares the minimum permission level it needs.
2. **Safe Mode** — enabled by default and blocks mutating/executable actions.
3. **Risk classification** — every tool action is assigned a risk category.
4. **Confirmation** — high-impact operations require explicit approval.
5. **Path scoping** — filesystem operations are restricted to configured roots.
6. **Auditability** — important actions are recorded with task/tool/status metadata.
7. **Timeouts** — commands have bounded execution time.
8. **No embedded secrets** — tokens and passwords are never hard-coded.
9. **External-action boundaries** — publishing, messaging and similar side effects require an explicit policy path.
10. **Cybersecurity boundaries** — cybersecurity features are limited to authorized defensive/educational use and should block credential theft, persistence, evasion, destructive actions and unauthorized access workflows.

## Permission levels

| Level | Capability |
|---:|---|
| 0 | Read-only |
| 1 | Create/edit user files |
| 2 | Execute approved local commands |
| 3 | Browser automation |
| 4 | External communication |
| 5 | Sensitive/destructive actions |

## Threats to address before production

The Phase 1 shell classifier is intentionally conservative and is not a complete command-security boundary. Before enabling unrestricted local execution, add an OS-level sandbox, command allowlists, privilege separation, signed tool manifests, process-tree cancellation, resource quotas, and a robust approval protocol.

Never treat an LLM's tool-selection output as authorization by itself. Authorization must be enforced by application code.
