# NOVA Database Schema — Phase 1 / Target Model

The Phase 1 runtime creates SQLite tables for `memories` and `audit_events`. The remaining target entities are documented here before implementation so later phases can migrate without changing the domain model.

## Core tables

### users
`id`, `created_at`, `status`, `display_name`

### sessions
`id`, `user_id`, `created_at`, `expires_at`, `revoked_at`

### conversations
`id`, `user_id`, `title`, `created_at`, `updated_at`

### messages
`id`, `conversation_id`, `role`, `content`, `created_at`

### tasks
`id`, `goal`, `status`, `mode`, `created_at`, `started_at`, `finished_at`, `result_json`

### task_steps
`id`, `task_id`, `sequence`, `title`, `tool`, `risk`, `permission`, `status`, `result_json`, `started_at`, `finished_at`

### memories
Implemented in Phase 1: `id`, `category`, `key`, `value`, `enabled`

### automations
`id`, `name`, `description`, `definition_json`, `enabled`, `created_at`, `updated_at`

### automation_runs
`id`, `automation_id`, `task_id`, `status`, `started_at`, `finished_at`, `result_json`

### permissions
`id`, `scope`, `resource`, `level`, `policy_json`, `created_at`, `updated_at`

### credentials_metadata
`id`, `provider`, `account_label`, `secret_ref`, `created_at`, `rotated_at`

Secrets themselves should live in a dedicated OS/cloud secret store rather than ordinary database columns.

### audit_events
Implemented in Phase 1: timestamp, event type, task ID, tool, risk, status and message.

### settings
`key`, `value_json`, `updated_at`

## Production database

SQLite is appropriate for local development. PostgreSQL should be used for multi-user or production deployments, with migrations managed separately from the application startup routine.
