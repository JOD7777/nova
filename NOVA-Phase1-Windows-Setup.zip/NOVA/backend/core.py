from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class PermissionLevel(int, Enum):
    READ_ONLY = 0
    USER_FILES = 1
    SAFE_COMMANDS = 2
    BROWSER_AUTOMATION = 3
    EXTERNAL_COMMUNICATION = 4
    SENSITIVE_DESTRUCTIVE = 5


class Settings(BaseSettings):
    app_name: str = "NOVA"
    environment: str = "development"
    database_url: str = "sqlite:///./nova.db"
    nova_safe_mode: bool = True
    allowed_roots: str = "."
    shell_timeout_seconds: int = 30
    max_retries: int = 2
    cors_origins: str = "http://localhost:5173"
    openai_api_key: str | None = None
    openai_model: str = "gpt-5-mini"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def roots(self) -> list[Path]:
        return [Path(p).expanduser().resolve() for p in self.allowed_roots.split(",") if p.strip()]


settings = Settings()


class TaskRequest(BaseModel):
    command: str = Field(min_length=1, max_length=8000)
    preview_only: bool = False


class TaskStep(BaseModel):
    id: str
    title: str
    tool: str | None = None
    risk: RiskLevel = RiskLevel.LOW
    permission: PermissionLevel = PermissionLevel.READ_ONLY
    status: str = "pending"
    result: dict[str, Any] | None = None


class TaskPlan(BaseModel):
    task_id: str
    goal: str
    steps: list[TaskStep]
    required_permissions: list[str] = []


class ToolResult(BaseModel):
    success: bool
    error_code: str | None = None
    message: str
    recoverable: bool = False
    suggested_action: str | None = None
    data: dict[str, Any] = {}
