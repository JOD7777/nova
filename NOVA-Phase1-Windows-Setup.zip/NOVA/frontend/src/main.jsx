import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const API = 'http://127.0.0.1:8000/api';

function App() {
  const [command, setCommand] = useState('');
  const [preview, setPreview] = useState(true);
  const [plan, setPlan] = useState(null);
  const [logs, setLogs] = useState([]);
  const [status, setStatus] = useState('Checking backend…');
  const [busy, setBusy] = useState(false);
  const [stopState, setStopState] = useState(false);

  async function refresh() {
    try {
      const [health, logRes] = await Promise.all([fetch(`${API}/health`), fetch(`${API}/logs`)]);
      setStatus(health.ok ? 'ONLINE' : 'OFFLINE');
      if (logRes.ok) setLogs(await logRes.json());
    } catch {
      setStatus('OFFLINE');
    }
  }

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 4000);
    return () => clearInterval(id);
  }, []);

  async function submit(e) {
    e.preventDefault();
    if (!command.trim() || busy) return;
    setBusy(true);
    try {
      const res = await fetch(`${API}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, preview_only: preview })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Request failed');
      setPlan(data);
      await refresh();
    } catch (err) {
      setPlan({ error: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function emergencyStop() {
    await fetch(`${API}/tasks/stop-all`, { method: 'POST' });
    setStopState(true);
    await refresh();
  }

  async function resetStop() {
    await fetch(`${API}/tasks/reset-stop`, { method: 'POST' });
    setStopState(false);
    await refresh();
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div>
          <div className="eyebrow">NEURAL OPERATIONS & VIRTUAL AUTOMATION</div>
          <h1>NOVA <span>AI</span></h1>
        </div>
        <div className="status"><span className={status === 'ONLINE' ? 'dot on' : 'dot'} /> {status}</div>
      </header>

      <main>
        <section className="hero card">
          <div className="hero-copy">
            <p className="label">COMMAND CENTER</p>
            <h2>Tell NOVA what you want to do.</h2>
            <p className="muted">Phase 1 runs with Safe Mode enabled: inspect, analyze, plan, preview, and audit.</p>
          </div>
          <form onSubmit={submit} className="command-form">
            <textarea value={command} onChange={(e) => setCommand(e.target.value)} placeholder="e.g. Make my cybersecurity project GitHub-ready" rows="4" />
            <div className="toolbar">
              <label className="toggle"><input type="checkbox" checked={preview} onChange={(e) => setPreview(e.target.checked)} /> Preview only</label>
              <button disabled={busy}>{busy ? 'PLANNING…' : 'RUN COMMAND'}</button>
            </div>
          </form>
        </section>

        <section className="grid two">
          <div className="card">
            <div className="section-head"><h3>Task Plan</h3><span>{plan?.plan?.task_id ? plan.plan.task_id.slice(0, 8) : '—'}</span></div>
            {plan?.error ? <div className="error">{plan.error}</div> : plan?.plan ? (
              <div className="steps">
                {plan.plan.steps.map((step, i) => <div className="step" key={step.id}>
                  <div className="step-no">{i + 1}</div>
                  <div className="step-body"><strong>{step.title}</strong><small>{step.tool || 'orchestrator'} · risk {step.risk} · permission L{step.permission}</small></div>
                  <span className={`pill ${step.status}`}>{step.status}</span>
                </div>)}
              </div>
            ) : <p className="muted">Submit a command to see NOVA's structured plan.</p>}
          </div>

          <div className="card">
            <div className="section-head"><h3>Execution Result</h3><span>Audit-ready</span></div>
            {plan?.execution ? <pre className="json">{JSON.stringify(plan.execution, null, 2)}</pre> : <p className="muted">Results and permission decisions will appear here.</p>}
          </div>
        </section>

        <section className="card stop-card">
          <div><p className="label">EMERGENCY CONTROL</p><h3>{stopState ? 'AUTOMATION STOPPED' : 'Automation control'}</h3><p className="muted">Stop active/queued NOVA work and block new execution until reset.</p></div>
          {stopState ? <button className="secondary" onClick={resetStop}>RESET STOP STATE</button> : <button className="danger" onClick={emergencyStop}>STOP ALL AUTOMATION</button>}
        </section>

        <section className="card">
          <div className="section-head"><h3>Recent Audit Log</h3><button className="linkbtn" onClick={refresh}>Refresh</button></div>
          <div className="log-list">{logs.length ? logs.map((l, i) => <div className="log" key={`${l.timestamp}-${i}`}><span>{new Date(l.timestamp).toLocaleTimeString()}</span><b>{l.event_type}</b><em>{l.status}</em><p>{l.message}</p></div>) : <p className="muted">No events yet.</p>}</div>
        </section>
      </main>
      <footer> N0VA Phase 1 · Safe Mode · Local-first foundation </footer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
