from backend.core import PermissionLevel, RiskLevel
from backend.orchestrator.planner import TaskPlanner
from backend.permissions.manager import PermissionManager


def test_planner_builds_github_workflow():
    plan = TaskPlanner().plan("Make my project GitHub-ready")
    assert len(plan.steps) >= 3
    assert plan.steps[-1].permission == PermissionLevel.EXTERNAL_COMMUNICATION


def test_safe_mode_blocks_mutating_action():
    decision = PermissionManager().decide(permission=PermissionLevel.USER_FILES, risk=RiskLevel.MEDIUM)
    assert decision.allowed is False


def test_read_only_allowed_in_safe_mode():
    decision = PermissionManager().decide(permission=PermissionLevel.READ_ONLY, risk=RiskLevel.LOW)
    assert decision.allowed is True


def test_shell_blocks_destructive_command():
    from backend.tools.shell import run_safe_command
    result = run_safe_command("rm -rf /tmp/example")
    assert result.error_code == "COMMAND_BLOCKED"


def test_shell_requests_confirmation_for_unknown_command():
    from backend.tools.shell import run_safe_command
    result = run_safe_command("curl https://example.com")
    assert result.error_code == "CONFIRMATION_REQUIRED"
