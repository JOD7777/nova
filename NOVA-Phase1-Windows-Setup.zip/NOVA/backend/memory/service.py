from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.database.db import Memory


def list_memories(db: Session):
    return db.scalars(select(Memory).order_by(Memory.id.desc())).all()


def upsert_memory(db: Session, category: str, key: str, value: str) -> Memory:
    item = db.scalar(select(Memory).where(Memory.key == key))
    if item is None:
        item = Memory(category=category, key=key, value=value, enabled=True)
        db.add(item)
    else:
        item.category = category
        item.value = value
        item.enabled = True
    db.commit()
    db.refresh(item)
    return item


def delete_memory(db: Session, memory_id: int) -> bool:
    item = db.get(Memory, memory_id)
    if item is None:
        return False
    db.delete(item)
    db.commit()
    return True
