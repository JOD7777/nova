# NOVA API Design

## Phase 1 endpoints

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | Service health |
| GET | `/api/tools` | Registered tools and policy metadata |
| POST | `/api/chat` | Turn a command into a plan and process it |
| POST | `/api/tasks/stop-all` | Activate emergency stop |
| POST | `/api/tasks/reset-stop` | Clear emergency stop state |
| GET | `/api/logs` | Recent audit events |
| GET | `/api/memory` | List memories |
| POST | `/api/memory` | Create/update a memory |
| DELETE | `/api/memory/{id}` | Delete a memory |

## Target API groups

`/chat`, `/tasks`, `/tools`, `/memory`, `/permissions`, `/automations`, `/logs`, `/settings`, `/integrations`, with authentication/session middleware applied before production exposure.

## Task contract

```json
{
  "task_id": "uuid",
  "goal": "string",
  "steps": [],
  "required_permissions": []
}
```

Tool results follow a structured contract with `success`, `error_code`, `message`, `recoverable`, `suggested_action`, and `data` fields.
