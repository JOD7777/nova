# NOVA — Neural Operations & Virtual Automation

NOVA is a modular personal AI automation platform foundation. It follows a control loop of **understand → plan → permission → execute → verify → log → report**.

## Phase 1 status

Implemented and functional:

- FastAPI backend with SQLite persistence
- Structured command planner
- Permission/risk gate
- Safe Mode by default
- Tool registry
- File inspection tool constrained to configured roots
- Shell tool with risk classification and timeout
- Memory CRUD foundation
- Audit logging
- Responsive command-center UI
- Task-plan visualization
- Tool/health/observability views
- Unit tests for planning and permission behavior

Not yet implemented in this phase: live model-provider reasoning, browser automation, GitHub/email adapters, voice/wake word, screen understanding, scheduler, production auth, PostgreSQL migrations, and full agent execution. The UI does not pretend those capabilities are active.

## Architecture

```text
User
 ↓
React Command Center
 ↓
FastAPI API
 ↓
Command Planner
 ↓
Orchestrator
 ↓
Permission / Risk Manager
 ↓
Tool Registry / Agents
 ↓
Execution
 ↓
Verification hooks
 ↓
SQLite Audit + Memory
```

## Project structure

```text
NOVA/
├── backend/
│   ├── api/
│   ├── agents/
│   ├── orchestrator/
│   ├── tools/
│   ├── permissions/
│   ├── memory/
│   ├── database/
│   ├── security/
│   └── services/
├── frontend/
│   └── src/
├── integrations/
│   ├── github/
│   ├── email/
│   ├── browser/
│   └── system/
├── tests/
├── docs/
├── scripts/
├── .env.example
├── requirements.txt
├── README.md
└── LICENSE
```

## Run locally

### Backend

```bash
cd NOVA
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
cp .env.example .env
uvicorn backend.main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown by the terminal, normally `http://localhost:5173`. The Phase 1 frontend is a functional command-center UI backed by the local FastAPI API.

## Safe Mode

`NOVA_SAFE_MODE=true` is the default. In this mode NOVA may inspect, analyze and preview, while mutating or executable operations are blocked by policy.

## Configuration

`ALLOWED_ROOTS` defines file-system locations NOVA may access. Use absolute paths in real deployments, separated by commas. Keep this scope narrow.

Never put API keys, passwords, GitHub tokens, OAuth secrets, or email passwords into source code. Use environment variables or a dedicated secrets manager.

## Roadmap

1. Phase 1 — Core UI + command system ✅
2. Phase 2 — Persistent task orchestration
3. Phase 3 — Expanded tool framework
4. Phase 4 — Sandboxed filesystem + shell execution
5. Phase 5 — Coding agent with verification
6. Phase 6 — Browser automation with confirmation controls
7. Phase 7 — Configurable memory and context
8. Phase 8 — Strong permission/security subsystem
9. Phase 9 — GitHub/email integrations
10. Phase 10 — Scheduler and reusable recipes
11. Phase 11 — Voice assistant
12. Phase 12 — Screen understanding
13. Phase 13 — Full security/integration/e2e testing
14. Phase 14 — Docker, PostgreSQL, HTTPS, production hardening

## Security

NOVA is designed for user-authorized automation. The cybersecurity layer is intended for defensive, educational, and authorized testing workflows. High-impact actions must remain visible, bounded, and auditable.

## License

MIT. See `LICENSE`.
