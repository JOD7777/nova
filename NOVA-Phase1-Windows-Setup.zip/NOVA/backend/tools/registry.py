from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Any

from backend.core import PermissionLevel, RiskLevel


@dataclass
class ToolSpec:
    name: str
    description: str
    risk: RiskLevel
    permission: PermissionLevel
    handler: Callable[..., Any]


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec) -> None:
        if spec.name in self._tools:
            raise ValueError(f"Tool already registered: {spec.name}")
        self._tools[spec.name] = spec

    def get(self, name: str) -> ToolSpec:
        return self._tools[name]

    def list(self) -> list[ToolSpec]:
        return list(self._tools.values())
