# NOVA Architecture Decision Record

## Technology stack

- Backend: Python + FastAPI
- Validation/config: Pydantic + pydantic-settings
- ORM/persistence: SQLAlchemy, SQLite for development
- Frontend: React + Vite
- Testing: pytest
- Deployment target: Docker Compose + PostgreSQL in later phase

## Core boundaries

### Orchestrator
Owns task lifecycle and delegates execution. It never directly bypasses the permission layer.

### Permission manager
Maps permission level and risk to allow/deny/confirmation-required decisions.

### Tool registry
Every executable capability is registered with a name, description, risk level, permission level and handler.

### Verification
Every completed tool operation should provide machine-readable evidence for a later verification pass.

### Audit
Important events are persisted for troubleshooting and accountability.

## Permission model

| Level | Purpose |
|---|---|
| 0 | Read-only |
| 1 | Create/edit user files |
| 2 | Safe local commands |
| 3 | Browser automation |
| 4 | External communication |
| 5 | Sensitive/destructive actions |

## API surface

- `GET /api/health`
- `GET /api/tools`
- `POST /api/chat`
- `POST /api/tasks/stop-all`
- `POST /api/tasks/reset-stop`
- `GET /api/logs`
- `GET /api/memory`
- `POST /api/memory`
- `DELETE /api/memory/{id}`

## Future integration design

Use provider adapters for model vendors and connector adapters for GitHub, email, browser and other external services. External side effects should always be explicit in policy and represented in the audit trail.
