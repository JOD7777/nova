# NOVA UI Design

The Phase 1 interface is a responsive command center designed around visibility of state rather than visual effects.

## Main areas

- Command Center: natural-language command input and preview toggle.
- System Control: backend status, tool count, memory count and emergency stop.
- Task: goal, step order, tool, risk and state.
- Activity Log: recent audit events.
- Tools: registered capabilities and required permission levels.

## Interaction rules

The interface should make the difference between **planned**, **preview**, **running**, **blocked**, **waiting for confirmation**, **completed**, **failed**, and **interrupted** visible. High-impact actions should expose what will happen before approval.
