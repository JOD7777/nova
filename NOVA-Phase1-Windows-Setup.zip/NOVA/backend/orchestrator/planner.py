from __future__ import annotations

import re
import uuid

from backend.core import PermissionLevel, RiskLevel, TaskPlan, TaskStep


class TaskPlanner:
    def plan(self, command: str) -> TaskPlan:
        text = command.strip()
        lowered = text.lower()
        steps: list[TaskStep] = []

        if any(k in lowered for k in ["github-ready", "github ready", "github repository"]):
            steps = [
                TaskStep(id="inspect", title="Inspect the project", tool="filesystem.inspect", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
                TaskStep(id="docs", title="Prepare project documentation", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
                TaskStep(id="tests", title="Plan or run project tests", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
                TaskStep(id="publish", title="Publish changes to GitHub", risk=RiskLevel.HIGH, permission=PermissionLevel.EXTERNAL_COMMUNICATION),
            ]
        elif "clean" in lowered and "download" in lowered:
            steps = [
                TaskStep(id="preview", title="Analyze Downloads and propose categories", tool="filesystem.inspect", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
                TaskStep(id="organize", title="Organize files after confirmation", risk=RiskLevel.MEDIUM, permission=PermissionLevel.USER_FILES),
            ]
        elif any(k in lowered for k in ["analyze this log", "analyze my security logs", "incident report"]):
            steps = [
                TaskStep(id="collect", title="Locate and inspect log input", tool="filesystem.inspect", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
                TaskStep(id="analyze", title="Correlate suspicious events and build a timeline", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
                TaskStep(id="report", title="Prepare an incident report", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
            ]
        elif any(k in lowered for k in ["fix this python error", "debug", "fix the error"]):
            steps = [
                TaskStep("inspect", "Inspect the project and error context", "filesystem.inspect", RiskLevel.LOW, PermissionLevel.READ_ONLY),
                TaskStep(id="repair", title="Propose or apply a bounded fix", risk=RiskLevel.MEDIUM, permission=PermissionLevel.USER_FILES),
                TaskStep(id="verify", title="Run relevant tests or checks", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY),
            ]
        else:
            steps = [TaskStep(id="understand", title="Interpret the command and identify the safest next action", risk=RiskLevel.LOW, permission=PermissionLevel.READ_ONLY)]

        required = sorted({step.permission.name.lower() for step in steps if step.permission.value > 0})
        return TaskPlan(task_id=str(uuid.uuid4()), goal=text, steps=steps, required_permissions=required)
