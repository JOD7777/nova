from __future__ import annotations

from pathlib import Path
from typing import Iterable

from backend.core import PermissionLevel, RiskLevel, ToolResult, settings


def _allowed(path: Path) -> bool:
    resolved = path.expanduser().resolve()
    return any(root == resolved or root in resolved.parents for root in settings.roots)


def inspect_path(path: str) -> ToolResult:
    target = Path(path).expanduser()
    if not _allowed(target):
        return ToolResult(success=False, error_code="PATH_DENIED", message="Path is outside NOVA's configured allowed roots.")
    if not target.exists():
        return ToolResult(success=False, error_code="FILE_NOT_FOUND", message="The requested path was not found.", recoverable=True, suggested_action="Check the path or search the selected directory.")
    if target.is_file():
        return ToolResult(success=True, message="File inspected.", data={"type": "file", "path": str(target.resolve()), "size": target.stat().st_size})
    children = [p.name for p in sorted(target.iterdir())[:100]]
    return ToolResult(success=True, message="Directory inspected.", data={"type": "directory", "path": str(target.resolve()), "entries": children})


def create_file(path: str, content: str) -> ToolResult:
    target = Path(path).expanduser()
    if not _allowed(target):
        return ToolResult(success=False, error_code="PATH_DENIED", message="Path is outside NOVA's configured allowed roots.")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ToolResult(success=True, message="File created.", data={"path": str(target.resolve())})
