from sqlalchemy.orm import Session

from backend.database.db import AuditEvent


def log_event(db: Session, *, event_type: str, status: str, message: str, task_id: str | None = None, tool: str | None = None, risk: str | None = None) -> None:
    db.add(AuditEvent(event_type=event_type, status=status, message=message, task_id=task_id, tool=tool, risk=risk))
    db.commit()
