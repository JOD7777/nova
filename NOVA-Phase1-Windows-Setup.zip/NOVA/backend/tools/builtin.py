from backend.core import PermissionLevel, RiskLevel
from backend.tools.filesystem import inspect_path, create_file
from backend.tools.registry import ToolRegistry, ToolSpec
from backend.tools.shell import run_safe_command


def build_registry() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(ToolSpec("filesystem.inspect", "Inspect a configured file or directory.", RiskLevel.LOW, PermissionLevel.READ_ONLY, inspect_path))
    registry.register(ToolSpec("filesystem.create_file", "Create a file inside a configured allowed root.", RiskLevel.MEDIUM, PermissionLevel.USER_FILES, create_file))
    registry.register(ToolSpec("shell.run", "Execute a local shell command subject to policy.", RiskLevel.MEDIUM, PermissionLevel.SAFE_COMMANDS, run_safe_command))
    return registry
