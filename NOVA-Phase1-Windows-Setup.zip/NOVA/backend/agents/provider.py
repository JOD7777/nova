from __future__ import annotations

from abc import ABC, abstractmethod


class AIProvider(ABC):
    @abstractmethod
    async def generate(self, system: str, user: str) -> str:
        raise NotImplementedError


class LocalRuleProvider(AIProvider):
    async def generate(self, system: str, user: str) -> str:
        return "NOVA is operating in local rule-based mode. Configure an AI provider to enable model-backed reasoning."
