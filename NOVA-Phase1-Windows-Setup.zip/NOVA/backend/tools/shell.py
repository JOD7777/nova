from __future__ import annotations

import shlex
import subprocess

from backend.core import ToolResult, settings

SAFE_BASE_COMMANDS = {
    "pwd", "ls", "dir", "whoami", "python", "python3", "pytest", "git", "node", "npm",
    "ip", "ipconfig", "uname", "cat", "type"
}


def classify_command(command: str) -> tuple[str, str]:
    text = command.strip().lower()
    destructive_tokens = ["rm -rf", "format ", "shutdown", "reboot", "del /f", "diskpart", "mkfs", "passwd", "net user"]
    external_tokens = ["git push", "git remote", "curl ", "wget ", "scp ", "ssh "]
    shell_chaining = [";", "&&", "||", "|", ">", "<", "$(", "`", "\n", "\r"]
    if any(token in text for token in destructive_tokens):
        return "critical", "Command can modify or destroy system state."
    if any(token in text for token in external_tokens):
        return "high", "Command can affect remote or external state."
    if any(token in command for token in shell_chaining):
        return "high", "Shell chaining or redirection requires explicit confirmation."
    try:
        tokens = shlex.split(command, posix=True)
    except ValueError:
        return "high", "Command could not be parsed safely."
    if not tokens or tokens[0] not in SAFE_BASE_COMMANDS:
        return "high", "Command is not in NOVA's Phase 1 safe command set."
    return "low", "Command is in the Phase 1 safe command set."


def run_safe_command(command: str, confirmed: bool = False) -> ToolResult:
    risk, reason = classify_command(command)
    if risk == "critical":
        return ToolResult(success=False, error_code="COMMAND_BLOCKED", message=f"Blocked: {reason}", recoverable=False)
    if risk == "high" and not confirmed:
        return ToolResult(success=False, error_code="CONFIRMATION_REQUIRED", message=f"Confirmation required: {reason}", recoverable=True)
    try:
        completed = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=settings.shell_timeout_seconds)
    except subprocess.TimeoutExpired:
        return ToolResult(success=False, error_code="COMMAND_TIMEOUT", message="Command exceeded the configured timeout.", recoverable=True, suggested_action="Inspect the command or increase the timeout.")
    return ToolResult(success=completed.returncode == 0, message="Command completed." if completed.returncode == 0 else "Command failed.", data={"stdout": completed.stdout, "stderr": completed.stderr, "exit_code": completed.returncode})
