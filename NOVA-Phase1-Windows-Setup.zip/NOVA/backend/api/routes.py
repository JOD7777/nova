from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.core import TaskRequest
from backend.database.db import AuditEvent, get_db
from backend.memory.service import delete_memory, list_memories, upsert_memory
from backend.orchestrator.engine import Orchestrator
from backend.orchestrator.planner import TaskPlanner

router = APIRouter()
planner = TaskPlanner()
orchestrator = Orchestrator()


@router.get("/health")
def health():
    return {"status": "ok", "service": "nova-backend"}


@router.get("/tools")
def tools():
    return [{"name": t.name, "description": t.description, "risk": t.risk.value, "permission": t.permission.value} for t in orchestrator.registry.list()]


@router.post("/chat")
def chat(request: TaskRequest, db: Session = Depends(get_db)):
    plan = planner.plan(request.command)
    result = orchestrator.execute(plan, db, preview_only=request.preview_only)
    return {"plan": plan.model_dump(), "execution": result}


@router.post("/tasks/stop-all")
def stop_all():
    orchestrator.stop_all()
    return {"status": "stopping", "message": "New tool execution is blocked until the stop state is reset."}


@router.post("/tasks/reset-stop")
def reset_stop():
    orchestrator.reset_stop()
    return {"status": "ready", "message": "Automation stop state cleared."}


@router.get("/logs")
def logs(db: Session = Depends(get_db)):
    events = db.scalars(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(100)).all()
    return [{"timestamp": e.timestamp.isoformat(), "event_type": e.event_type, "task_id": e.task_id, "tool": e.tool, "risk": e.risk, "status": e.status, "message": e.message} for e in events]


@router.get("/memory")
def memories(db: Session = Depends(get_db)):
    return [{"id": m.id, "category": m.category, "key": m.key, "value": m.value, "enabled": m.enabled} for m in list_memories(db)]


@router.post("/memory")
def save_memory(payload: dict, db: Session = Depends(get_db)):
    for key in ("category", "key", "value"):
        if not isinstance(payload.get(key), str) or not payload[key].strip():
            raise HTTPException(status_code=400, detail=f"Missing or invalid field: {key}")
    item = upsert_memory(db, payload["category"], payload["key"], payload["value"])
    return {"id": item.id, "category": item.category, "key": item.key, "value": item.value, "enabled": item.enabled}


@router.delete("/memory/{memory_id}")
def remove_memory(memory_id: int, db: Session = Depends(get_db)):
    if not delete_memory(db, memory_id):
        raise HTTPException(status_code=404, detail="Memory not found")
    return {"status": "deleted"}
